package agents;

import org.camunda.bpm.model.bpmn.Bpmn;
import org.camunda.bpm.model.bpmn.instance.*;
import org.camunda.bpm.model.bpmn.instance.Process;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

public class AgentGenerator {

    private static final String AGENT_BASE_DIR = "c:/agent"; // Katalog bazowy
    private static final String AGENT_DIR = AGENT_BASE_DIR + "/agents"; // Katalog wyjściowy dla plików .java i .class agentów
    private static final String CHECKSUM_FILE = AGENT_BASE_DIR + "/bpmn_checksum.txt"; // Plik sumy kontrolnej

    public static void main(String[] args) throws Exception {
        // Wczytaj model BPMN
        File bpmnFile = new File(AGENT_BASE_DIR + "/model.bpmn");
        var modelInstance = Bpmn.readModelFromFile(bpmnFile);

        // Sprawdź, czy plik BPMN uległ zmianie
        String currentChecksum = calculateChecksum(bpmnFile);
        String previousChecksum = loadPreviousChecksum();

        if (!currentChecksum.equals(previousChecksum)) {
            System.out.println("Plik BPMN został zmieniony lub to pierwsze uruchomienie. Generowanie kodu agentów...");
            generateAgents(modelInstance, AGENT_DIR);
            saveChecksum(currentChecksum);
        } else {
            System.out.println("Plik BPMN nie uległ zmianie. Używanie istniejących plików agentów.");
        }

        // Kompilacja wygenerowanych klas agentów
        compileAgents(AGENT_BASE_DIR);
    }

    // Metoda do obliczania sumy kontrolnej pliku BPMN
    private static String calculateChecksum(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("MD5");
        byte[] bytes = Files.readAllBytes(file.toPath());
        byte[] hashBytes = digest.digest(bytes);
        StringBuilder sb = new StringBuilder();
        for (byte b : hashBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    // Wczytaj poprzednią sumę kontrolną
    private static String loadPreviousChecksum() {
        try {
            return new String(Files.readAllBytes(Paths.get(CHECKSUM_FILE)), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    // Zapisz obecną sumę kontrolną
    private static void saveChecksum(String checksum) {
        try {
            Files.write(Paths.get(CHECKSUM_FILE), checksum.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Generowanie kodu agentów
    private static void generateAgents(org.camunda.bpm.model.bpmn.BpmnModelInstance modelInstance, String outputDir) throws IOException {
        // Upewnij się, że katalog agentów istnieje
        Path agentDir = Paths.get(outputDir);
        if (!Files.exists(agentDir)) {
            Files.createDirectories(agentDir);
        }

        // Kopiowanie klasy Token.java z folderu template do katalogu agentów
        copyTokenClass(agentDir);

        // Pobierz wszystkie węzły przepływu
        Collection<FlowNode> flowNodes = modelInstance.getModelElementsByType(FlowNode.class);

        // Mapa przechowująca nazwy agentów i ich następców
        Map<String, List<String>> agentSuccessors = new HashMap<>();

        // Budowanie mapy następców na podstawie przepływów BPMN
        for (FlowNode node : flowNodes) {
            String agentName = getAgentName(node);
            List<String> successors = new ArrayList<>();
            for (FlowNode successor : node.getSucceedingNodes().list()) {
                successors.add(getAgentName(successor));
            }
            agentSuccessors.put(agentName, successors);
        }

        // Generowanie kodu dla każdego agenta
        for (FlowNode node : flowNodes) {
            String agentName = getAgentName(node);
            String className = agentName;
            String code = generateAgentCode(node, className, agentSuccessors.get(agentName));
            Path filePath = agentDir.resolve(className + ".java");
            Files.write(filePath, code.getBytes(StandardCharsets.UTF_8));
        }
    }

    // Kopiowanie klasy Token.java z folderu template do katalogu agentów
    private static void copyTokenClass(Path agentDir) throws IOException {
        Path sourcePath = Paths.get("template", "Token.java");
        Path targetPath = agentDir.resolve("Token.java");
        Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Skopiowano Token.java do katalogu agentów.");
    }

    // Pomocnicza metoda do uzyskania nazwy agenta
    private static String getAgentName(BaseElement element) {
        String name = element.getAttributeValue("name");
        if (name == null || name.isEmpty()) {
            name = element.getElementType().getTypeName() + "_" + element.getId();
        } else {
            name = sanitizeName(name) + "_" + element.getId();
        }
        return name;
    }

    // Metoda sanitizująca nazwy
    private static String sanitizeName(String name) {
        // Usuń znaki inne niż litery i cyfry
        name = name.replaceAll("[^a-zA-Z0-9]", "_");

        // Skróć nazwę, jeśli jest zbyt długa (np. do 50 znaków)
        if (name.length() > 50) {
            name = name.substring(0, 50);
        }

        // Jeśli nazwa zaczyna się od cyfry, dodaj podkreślenie na początku
        if (!name.isEmpty() && Character.isDigit(name.charAt(0))) {
            name = "_" + name;
        }

        return name;
    }

    // Generowanie kodu dla agenta
    private static String generateAgentCode(FlowNode node, String className, List<String> successors) throws IOException {
        String template;

        // Wybór szablonu na podstawie typu węzła
        if (node instanceof StartEvent) {
            template = readTemplate("StartEventAgentTemplate.java");
        } else if (node instanceof EndEvent) {
            template = readTemplate("EndEventAgentTemplate.java");
        } else if (node instanceof Task) {
            template = readTemplate("TaskAgentTemplate.java");
        } else if (node instanceof ExclusiveGateway) {
            template = readTemplate("XorGatewayAgentTemplate.java");
        } else if (node instanceof ParallelGateway) {
            template = readTemplate("AndGatewayAgentTemplate.java");
        } else {
            // Domyślnie używamy szablonu dla zadania
            template = readTemplate("TaskAgentTemplate.java");
        }

        // Przygotuj ciąg znaków z listą następców
        String successorsString = "";
        for (int i = 0; i < successors.size(); i++) {
            successorsString += "\"" + successors.get(i) + "\"";
            if (i < successors.size() - 1) {
                successorsString += ", ";
            }
        }

        // Zastąp znaczniki zastępcze w szablonie
        template = template.replace("{{CLASS_NAME}}", className);
        template = template.replace("{{SUCCESSORS}}", successorsString);

        // Dodatkowa logika dla bramek XOR
        if (node instanceof ExclusiveGateway) {
            template = template.replace("{{GATEWAY_LOGIC}}", "Random rand = new Random();\n        String nextAgent = successors.get(rand.nextInt(successors.size()));");
        } else {
            template = template.replace("{{GATEWAY_LOGIC}}", "String nextAgent = successors.get(0);");
        }

        // Dodatkowa logika dla StartEvent i EndEvent
        if (node instanceof StartEvent) {
            template = template.replace("{{START_EVENT_LOGIC}}", "/* Logika dla StartEvent */");
        } else if (node instanceof EndEvent) {
            template = template.replace("{{END_EVENT_LOGIC}}", "/* Logika dla EndEvent */");
        } else {
            // Usuń znaczniki, jeśli nie są potrzebne
            template = template.replace("{{START_EVENT_LOGIC}}", "");
            template = template.replace("{{END_EVENT_LOGIC}}", "");
        }

        return template;
    }

    // Odczyt szablonu z pliku
    private static String readTemplate(String templateName) throws IOException {
        // Użyj ścieżki relatywnej do katalogu projektu
        Path templatePath = Paths.get("template", templateName);
        return new String(Files.readAllBytes(templatePath), StandardCharsets.UTF_8);
    }

    // Kompilacja wygenerowanych klas agentów
    private static void compileAgents(String directory) throws IOException {
        Path agentDir = Paths.get(directory);

        // Użycie kompilatora Java
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            throw new RuntimeException("Brak kompilatora Java. Upewnij się, że używasz JDK, a nie JRE.");
        }

        // Zbieranie wszystkich plików .java
        List<String> javaFiles = new ArrayList<>();
        Files.walk(agentDir)
                .filter(path -> path.toString().endsWith(".java"))
                .forEach(javaFile -> javaFiles.add(javaFile.toString()));

        if (javaFiles.isEmpty()) {
            System.out.println("Nie znaleziono plików .java do kompilacji.");
            return;
        }

        // Przygotowanie opcji kompilacji
        List<String> optionList = new ArrayList<>();
        optionList.add("-d");
        optionList.add(agentDir.toString()); // Katalog wyjściowy

        // Jeśli agenci korzystają z bibliotek zewnętrznych (np. JADE), dodaj je do classpath
        // Przykład, jeśli masz jade.jar w katalogu lib
        // optionList.add("-classpath");
        // optionList.add("lib/jade.jar");

        // Kompilacja plików
        JavaCompiler.CompilationTask task = compiler.getTask(
                null,
                null,
                null,
                optionList,
                null,
                compiler.getStandardFileManager(null, null, null).getJavaFileObjectsFromStrings(javaFiles)
        );

        boolean success = task.call();
        if (success) {
            System.out.println("Kompilacja zakończona sukcesem.");
        } else {
            System.out.println("Kompilacja nie powiodła się.");
        }
    }
}
