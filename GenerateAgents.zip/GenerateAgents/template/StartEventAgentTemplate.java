package agents;

import jade.core.Agent;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.MessageTemplate;
import java.util.*;

public class {{CLASS_NAME}} extends Agent {
    private List<String> successors = Arrays.asList({{SUCCESSORS}});

    protected void setup() {
        // Dodanie zachowania do odbierania wiadomości "start"
        addBehaviour(new StartEventBehaviour());

        // Dodanie zachowania do odbierania standardowych wiadomości
        addBehaviour(new MessageReceiverBehaviour());
    }

    // Zachowanie do odbierania wiadomości "start" i inicjowania przepływu tokenu
    private class StartEventBehaviour extends CyclicBehaviour {
        @Override
        public void action() {
            // Tworzenie szablonu wiadomości oczekującej na treść "start"
            MessageTemplate mt = MessageTemplate.MatchContent("start");
            ACLMessage msg = receive(mt);
            if (msg != null) {
                // Logika dla StartEvent
                System.out.println(getLocalName() + " otrzymał wiadomość 'start'.");

                // Inicjalizacja tokenu
                Token token = new Token();
                token.addAgent(getLocalName());

                // Przekazanie tokenu do następców
                if (successors.isEmpty()) {
                    // Brak następców
                    System.out.println("Brak następców dla agenta początkowego.");
                } else {
                    for (String nextAgent : successors) {
                        ACLMessage forwardMsg = new ACLMessage(ACLMessage.INFORM);
                        forwardMsg.addReceiver(new AID(nextAgent, AID.ISLOCALNAME));
                        try {
                            forwardMsg.setContentObject(token);
                            send(forwardMsg);
                            System.out.println(getLocalName() + " wysłał token do " + nextAgent);
                            
                            // Opcjonalnie: wysyłanie kopii do LoggingAgent
                            ACLMessage logMsg = new ACLMessage(ACLMessage.INFORM);
                            logMsg.addReceiver(new AID("LoggingAgent", AID.ISLOCALNAME));
                            logMsg.setContent("Token sent from " + getLocalName() + " to " + nextAgent);
                            send(logMsg);
                            System.out.println(getLocalName() + " wysłał kopię wiadomości do LoggingAgent");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

                // Usunięcie zachowania po wysłaniu tokenu, jeśli nie chcesz, żeby agent dalej działał
                // removeBehaviour(this);
            } else {
                block();
            }
        }
    }

    // Zachowanie do odbierania standardowych wiadomości ACLMessage
    private class MessageReceiverBehaviour extends CyclicBehaviour {
        @Override
        public void action() {
            ACLMessage msg = receive();
            if (msg != null) {
                System.out.println(getLocalName() + " otrzymał wiadomość: " + msg.getContent());
                // Możesz dodać dodatkową logikę przetwarzania wiadomości tutaj
            } else {
                block();
            }
        }
    }
}
