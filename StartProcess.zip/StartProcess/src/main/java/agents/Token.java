package agents;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Token implements Serializable {
    private List<String> agentHistory = new ArrayList<>();
    private List<LocalDateTime> timeStamps = new ArrayList<>();

    public void addAgent(String agentId) {
        agentHistory.add(agentId);
        timeStamps.add(LocalDateTime.now());
    }

    public List<String> getAgentHistory() {
        return agentHistory;
    }

    public List<LocalDateTime> getTimeStamps() {
        return timeStamps;
    }
}
