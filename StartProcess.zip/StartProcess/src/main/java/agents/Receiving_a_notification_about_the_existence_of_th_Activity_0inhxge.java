package agents;

import jade.core.Agent;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.core.behaviours.CyclicBehaviour;
import java.util.*;


public class Receiving_a_notification_about_the_existence_of_th_Activity_0inhxge extends Agent {
    private List<String> successors = Arrays.asList("Check_for_the_existence_of_the_casette_Activity_1e74rbv");

    protected void setup() {
        addBehaviour(new ReceiveTokenBehaviour());
    }

    private class ReceiveTokenBehaviour extends CyclicBehaviour {
        public void action() {
            ACLMessage msg = receive();
            if (msg != null) {
                try {
                    Token token = (Token) msg.getContentObject();
                    token.addAgent(getLocalName());

                    if (successors.isEmpty()) {
                        // No successors, send to EndAgent
                        ACLMessage endMsg = new ACLMessage(ACLMessage.INFORM);
                        endMsg.addReceiver(new AID("EndAgent", AID.ISLOCALNAME));
                        endMsg.setContentObject(token);
                        send(endMsg);
                    } else {
                        // Choose the next agent (first in the list)
                        String nextAgent = successors.get(0);
                        ACLMessage forwardMsg = new ACLMessage(ACLMessage.INFORM);
                        forwardMsg.addReceiver(new AID(nextAgent, AID.ISLOCALNAME));
                        forwardMsg.setContentObject(token);
                        send(forwardMsg);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                block();
            }
        }
    }
}
