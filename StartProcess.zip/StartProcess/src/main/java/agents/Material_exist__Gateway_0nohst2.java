package agents;

import jade.core.Agent;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import jade.core.behaviours.CyclicBehaviour;
import java.util.*;

public class Material_exist__Gateway_0nohst2 extends Agent {
    private List<String> successors = Arrays.asList("Transport_basket_to_the_dehydration_station_Activity_1tubtnq", "Checking_the_number_of_items_and_fitting_them_into_Activity_0rpt3xz");

    protected void setup() {
        addBehaviour(new ReceiveTokenBehaviour());
    }

    private class ReceiveTokenBehaviour extends CyclicBehaviour {
        public void action() {
            ACLMessage msg = receive();
            if (msg != null) {
                try {
                    Token token = (Token) msg.getContentObject();
                    token.addAgent(getLocalName());

                    if (successors.isEmpty()) {
                        // No successors, send to EndAgent
                        ACLMessage endMsg = new ACLMessage(ACLMessage.INFORM);
                        endMsg.addReceiver(new AID("EndAgent", AID.ISLOCALNAME));
                        endMsg.setContentObject(token);
                        send(endMsg);
                    } else {
                        // XOR Gateway - choose a random successor
                        Random rand = new Random();
        String nextAgent = successors.get(rand.nextInt(successors.size()));
                        ACLMessage forwardMsg = new ACLMessage(ACLMessage.INFORM);
                        forwardMsg.addReceiver(new AID(nextAgent, AID.ISLOCALNAME));
                        forwardMsg.setContentObject(token);
                        send(forwardMsg);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                block();
            }
        }
    }
}
