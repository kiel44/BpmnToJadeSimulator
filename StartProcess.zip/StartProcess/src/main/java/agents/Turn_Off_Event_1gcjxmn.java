package agents;

import jade.core.Agent;
import jade.lang.acl.ACLMessage;
import jade.core.behaviours.CyclicBehaviour;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

public class Turn_Off_Event_1gcjxmn extends Agent {
    protected void setup() {
        addBehaviour(new EndEventBehaviour());
    }

    private class EndEventBehaviour extends CyclicBehaviour {
        public void action() {
            ACLMessage msg = receive();
            if (msg != null) {
                try {
                    Token token = (Token) msg.getContentObject();
                    token.addAgent(getLocalName());
                    // Logika dla EndEvent
                    /* Logika dla EndEvent */
                    generateReport(token);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                // Usunięcie zachowania po przetworzeniu tokenu
                removeBehaviour(this);
            } else {
                block();
            }
        }
    }

    private void generateReport(Token token) {
        StringBuilder report = new StringBuilder();
        for (int i = 0; i < token.getAgentHistory().size(); i++) {
            report.append("Agent: ").append(token.getAgentHistory().get(i))
                  .append(", Czas: ").append(token.getTimeStamps().get(i).toString())
                  .append("\n");
        }
        Path reportPath = Paths.get("process_report.txt");
        try {
            Files.write(reportPath, report.toString().getBytes(StandardCharsets.UTF_8));
            System.out.println("Raport został wygenerowany.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
